# EVI Electric Starter

This is a starter full-stack project for testing the user flow.

## Run locally
1. Install Node.js.
2. In this folder run `npm install`
3. Run `npm start`
4. Open http://localhost:3000

## Important
This starter uses in-memory storage and plain demo authentication. It is NOT production-ready for real money. Before a real launch, add a real database, password hashing, session/JWT security, HTTPS, server-side validation, audit logs, payment-gateway verification/webhooks, and a compliant withdrawal process. Never credit a user's wallet merely because the client says payment succeeded.
